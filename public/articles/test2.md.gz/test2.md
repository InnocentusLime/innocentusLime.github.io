# Hello everybody!

My name is [[ insert letsplayer name ]] and welcome to the markdown rendering test. I have never tried this, so lets go and give it a try, *shall we*?! THis should be a very fun one! And I feel so excited to review this frontend.

Now as you are reading this, this article is actually read from an `.MD` file, which is then parsed and rendered on **THIS** website!

```rust
let amogus = new Crewmate()
amogus.getSus()
``` 
